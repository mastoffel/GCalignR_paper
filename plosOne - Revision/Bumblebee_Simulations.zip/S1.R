sink("S1_Status_Summary.txt",append = FALSE) # Prepare a Text file
cat(paste(Sys.time(),"\n"))
sink()


library(GCalignR)
library(ggplot2)
## small function to test parameters in align_chromatograms 
source("R/optimal_params.R")
## calculates errors by matching aligned data to a table of known substances
source("R/error_rate.R")
## custom function for simulations based on chromatograms
source("R/ChromaSimFunctions.R")

## we align that untreated datasets in order to extract input retention times
bbim_zero <- align_chromatograms(data = "data/bbim.txt",rt_col_name = "RT")
save(bbim_zero,file = "data/bbim_zero.RData")
beph_zero <- align_chromatograms(data = "data/beph.txt",rt_col_name = "RT")
save(beph_zero,file = "data/beph_zero.RData")
bfla_zero <- align_chromatograms(data = "data/bfla.txt",rt_col_name = "RT")
save(bfla_zero,file = "data/bfla_zero.RData")

load("data/bbim_zero.RData")
load("data/beph_zero.RData")
load("data/bfla_zero.RData")

bfla_chroma <- lapply(bfla_zero[["input_list"]],na.remove) # remove NAs
bbim_chroma <- lapply(bbim_zero[["input_list"]],na.remove) # remove NAs
beph_chroma <- lapply(beph_zero[["input_list"]],na.remove) # remove NAs

bfla_out <- sim_linear_shift(bfla_chroma,
                             rt_col_name = "RT",shifts = c(-0.03,0.03))
bfla_shifted <- bfla_out[["Chromas"]] 

p <- rep(seq(from = 0,to = 1,by = 0.1),each = 10)
bfla_data <- list()
names <- character()
for (i in 1:length(p)) { 
  ## add errors
  sink("S1_Status_Summary.txt",append = TRUE) # Prepare a Text file
  cat(paste("\n","BFLA",Sys.time(), "Iteratation", as.character(i), "of", as.character(length(p))))
  sink()
  
  temp <- lapply(bfla_shifted,add_peak_error,p = p[i],
                 rt_col_name = "RT",conc_col_name = "Area",
                 distr = c(-0.02,-0.01,0.01,0.02)) 
  ## extract peak list
  temp <- lapply(temp, FUN = function(x) x[["chroma"]])
  aligned <- align_chromatograms(temp,rt_col_name = "RT",max_linear_shift = 0.05)     
  ## We need the "true" retention times for referencing purposes
  aligned <- original_rt(org = bfla_chroma,aligned = aligned,rt_col_name = "RT")
  bfla_data <- append(bfla_data,list(aligned))
  names <- c(names,paste0("no_",as.character(i),"_noise_",as.character(p[i])))
}
names(bfla_data) <- names
bfla_simulations <- list(OptAlign = bfla_zero,SimAlign = bfla_data,noise = p) 
save(x = bfla_simulations,file = paste0("data/","bfla_simulations",".RData"))   

bbim_out <- sim_linear_shift(bbim_chroma,
                             rt_col_name = "RT",shifts = c(-0.03,0.03))
bbim_shifted <- bbim_out[["Chromas"]] # linearly shifted sample

p <- rep(seq(from = 0,to = 1,by = 0.1),each = 10)
bbim_data <- list()
names <- character()
for (i in 1:length(p)) { 
  sink("S1_Status_Summary.txt",append = TRUE) # Prepare a Text file
  cat(paste("\n","BBIM",Sys.time(), "Iteratation", as.character(i), "of", as.character(length(p))))
  sink()
  ## add errors
  temp <- lapply(bbim_shifted,add_peak_error,p = p[i],
                 rt_col_name = "RT",conc_col_name = "Area",
                 distr = c(-0.02,-0.01,0.01,0.02)) 
  ## extract peak list
  temp <- lapply(temp, FUN = function(x) x[["chroma"]])
  aligned <- align_chromatograms(temp,
                                 rt_col_name = "RT",max_linear_shift = 0.05)
  ## We need the "true" retention times for referencing purposes
  aligned <- original_rt(org = bbim_chroma,aligned = aligned,rt_col_name = "RT")
  bbim_data <- append(bbim_data,list(aligned))
  names <- c(names,paste0("no_",as.character(i),"_noise_",as.character(p[i])))
}
names(bbim_data) <- names
bbim_simulations <- list(OptAlign = bbim_zero,SimAlign = bbim_data,noise = p) 
save(x = bbim_simulations,file = paste0("data/","bbim_simulations",".RData"))   

beph_out <- sim_linear_shift(beph_chroma,
                             rt_col_name = "RT",shifts = c(-0.03,0.03))
beph_shifted <- beph_out[["Chromas"]] # linearly shifted sample

p <- rep(seq(from = 0,to = 1,by = 0.1),each = 10)
beph_data <- list()
names <- character()
for (i in 1:length(p)) { 
  sink("S1_Status_Summary.txt",append = TRUE) # Prepare a Text file
  cat(paste("\n","BEPH",Sys.time(), "Iteratation", as.character(i), "of", as.character(length(p))))
  sink()
  ## add errors
  temp <- lapply(beph_shifted,add_peak_error,p = p[i],
                 rt_col_name = "RT",conc_col_name = "Area",distr = c(-0.02,-0.01,0.01,0.02)) 
  ## extract peak list
  temp <- lapply(temp, FUN = function(x) x[["chroma"]])
  aligned <- align_chromatograms(temp,rt_col_name = "RT", max_linear_shift = 0.05)    
  ## We need the "true" retention times for referencing purposes
  aligned <- original_rt(org = beph_chroma,aligned = aligned,rt_col_name = "RT")
  beph_data <- append(beph_data,list(aligned))
  names <- c(names,paste0("no_",as.character(i),"_noise_",as.character(p[i])))
}
names(beph_data) <- names
beph_simulations <- list(OptAlign = beph_zero,SimAlign = beph_data,noise = p) 
save(x = beph_simulations,file = paste0("data/","beph_simulations",".RData"))   

load("data/bfla_simulations.RData")
load("data/beph_simulations.RData")
load("data/bbim_simulations.RData")
## set up data frames
bfla <- data.frame(data.frame(noise = bfla_simulations[["noise"]]))
bbim <- data.frame(data.frame(noise = bbim_simulations[["noise"]]))
beph <- data.frame(data.frame(noise = beph_simulations[["noise"]]))
## calculate errors
bfla[["error"]] <- unlist(lapply(X = bfla_simulations[["SimAlign"]],
                                 error_rate, Reference = "data/bfla_ms.txt",
                                 rt_col_name = "RT", linshift = FALSE))
bbim[["error"]] <- unlist(lapply(X = bbim_simulations[["SimAlign"]],
                                 error_rate, Reference = "data/bbim_ms.txt",
                                 rt_col_name = "RT", linshift = FALSE))
beph[["error"]] <- unlist(lapply(X = beph_simulations[["SimAlign"]],
                                 error_rate, Reference = "data/beph_ms.txt",
                                 rt_col_name = "RT",linshift = FALSE))
## Combine data into one data frame
df <- rbind(bbim,bfla,beph)
df[["id"]] <- rep(c("bbim","bfla","beph"),each = nrow(df)/3)
save(df,file = "data/df_bumblebee.RData")

load("data/df_bumblebee.RData")
plot <- ggplot2::ggplot(data = df,aes(x = noise, y = error, group = id, col = id, fill = id)) + 
  geom_smooth(level = 0.95, size = 1.5, alpha = 0.2) + 
  theme_bw(base_size = 14, base_family = "sans") + 
  theme(panel.grid.major = element_blank(),
        panel.grid.minor = element_blank(),
        aspect.ratio = 1,
        legend.justification = c(0,0),
        legend.position = c(0.7,0.02),
        legend.background = element_rect(color = "black",fill = NA)) +
  xlab("Additional noise level") +
  ylab("Error rate") +
  scale_x_continuous(breaks = seq(0,1,0.1), expand = c(0,0)) +
  scale_y_continuous(breaks = seq(0,0.3,0.02), expand = c(0,0)) +
  scale_colour_manual(values = c("#1B9E77", "#D95F02", "#7570B3"),
                      name = "Bumblebee datasets",
                      breaks = c("bbim", "beph", "bfla"),
                      labels = c("Bombus bimaculatus",
                                 "B. ephippiatus",
                                 "B. flavifrons"),
                      guide = guide_legend(
                        label.theme = element_text(
                          face = "italic", angle = 0,
                          size = 12))) +
  
  scale_fill_manual(values = c("#1B9E77", "#D95F02", "#7570B3"),
                    name = "Bumblebee datasets",
                    breaks = c("bbim", "beph", "bfla"),
                    labels = c("Bombus bimaculatus",
                               "B. ephippiatus",
                               "B. flavifrons"),
                    guide = guide_legend(
                      label.theme = element_text(
                        face = "italic", angle = 0,
                        size = 12)))

ggsave(plot,filename = "figures/bumblebee_noise_simulation.tif",device = "tiff",dpi = 300,width = 8,height = 8,units = "in")
