library(GCalignR)
library(ggplot2)
library(gtable)
library(vegan)
source("R/ChromaSimFunctions.R")
source("R/NMDS-Functions.R")
source("R/ggplot_dual_axis.R")
source("R/ggplot_shared_x_axis.R")
sink("S3_Status_Summary.txt",append = FALSE) # Prepare a Text file
cat(paste(Sys.time(),"\n"))
sink()

chromas <- aligned_peak_data[["input_list"]]
sim_zero <- align_chromatograms(data = chromas,rt_col_name = "time",max_linear_shift = 0.02,rt_cutoff_low = 8,blanks = c("C2","C3"),reference = "P38")

p <- rep(seq(from = 0,to = 1,by = 0.1),each = 10)
sim_data <- list()
names <- character()
for (i in 1:length(p)) { 
sink("S3_Status_Summary.txt",append = TRUE) # Prepare a Text file
cat(paste("\n",Sys.time(), "Iteratation", as.character(i), "of", as.character(length(p))))
sink()
  
temp <- lapply(chromas,add_peak_error,p = p[i],
                 rt_col_name = "time",conc_col_name = "area",
                 distr = c(-0.02,-0.01,0.01,0.02)) 
  temp <- lapply(temp, FUN = function(x) x[["chroma"]])
  aligned <- align_chromatograms(temp, rt_col_name = "time",max_linear_shift = 0.05,rt_cutoff_low = 8,delete_single_peak = T,blanks = c("C2","C3"),reference = "P38")
  ## We need the "true" retention times for referencing purposes
  aligned <- original_rt(org = chromas,aligned = aligned,rt_col_name = "time")
  sim_data <- append(sim_data,list(aligned))
  names <- c(names,paste0("no_",as.character(i),"_noise_",as.character(p[i])))
}
names(sim_data) <- names
seal_simulations <- list(OptAlign = sim_zero,SimAlign = sim_data,noise = p) 
save(x = seal_simulations,file = paste0("data/","seal_simulations",".RData"))

load("data/seal_simulations.RData")
aligned <- seal_simulations[["SimAlign"]]
data("peak_factors")
covars <- peak_factors

scent <- lapply(aligned, scent_extract,covars = covars) # get the scent, normalised and log+1 transformed
save(x = scent,file = "data/scent.RData")
scent_mds <- lapply(scent, myMetaMDS, covars) # MDS using vegan::metaMDS
save(x = scent_mds,file = "data/scent_mds.RData")

load(file = "data/scent_mds.RData")
load(file = "data/scent.RData")


scent_adonis_colony <- lapply(scent, adonis_colony,covars) # calculates the adonis stats
save(x = scent_adonis_colony, file = "data/scent_adonis_colony.RData")
load(file = "data/scent_adonis_colony.RData") 
load(file = "data/seal_simulations.RData")

noise <- factor(seal_simulations[["noise"]])
r2 <- unlist(lapply(scent_adonis_colony, function(x) x[["aov.tab"]][["R2"]][1]))
p.val <- unlist(lapply(scent_adonis_colony, function(x) x[["aov.tab"]][["Pr(>F)"]][1]))
peaks <- unlist(lapply(seal_simulations[["SimAlign"]],function(x) x[["Logfile"]][["Aligned"]][["retained"]]))
df <- data.frame(noise, r2, p.val, peaks)

